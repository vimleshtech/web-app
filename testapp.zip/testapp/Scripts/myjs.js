﻿
function tax(amt) {

    alert(amt * .18);

}